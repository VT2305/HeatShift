# HeatShift source catalog

## Production-grade core sources

| Source | Endpoint or page | Update pattern | HeatShift use | Important limitation |
|---|---|---|---|---|
| NEA WBGT observations via data.gov.sg | `https://api-open.data.gov.sg/v2/real-time/api/weather?api=wbgt` | Fifteen-minute average, updated every 15 minutes | Authoritative environmental trigger and replay data | Public station may not represent microclimate at a regulated worksite; use an on-site meter where MOM requires one |
| NEA air temperature | `https://api-open.data.gov.sg/v2/real-time/api/air-temperature` | Station level, updated every 5 minutes | Supporting context and anomaly diagnostics | Not a substitute for WBGT |
| NEA relative humidity | `https://api-open.data.gov.sg/v2/real-time/api/relative-humidity` | Station level, updated every 5 minutes | Supporting context | Not enough to calculate authoritative outdoor WBGT |
| NEA wind speed | `https://api-open.data.gov.sg/v2/real-time/api/wind-speed` | Station level, updated every 5 minutes | Supporting context | Stations may differ from the closest WBGT station |
| NEA rainfall | `https://api-open.data.gov.sg/v2/real-time/api/rainfall` | Station level | Operational context and future adverse-weather extension | Not part of the current heat rule calculation |
| NEA 2-hour forecast | `https://api-open.data.gov.sg/v2/real-time/api/two-hr-forecast` | Live forecast | Operational heads-up and refresh trigger | Does not forecast WBGT |
| NEA 24-hour forecast | `https://api-open.data.gov.sg/v2/real-time/api/twenty-four-hr-forecast` | Live forecast | Planning context | Does not forecast WBGT |
| MOM heat-stress measures | `https://www.mom.gov.sg/heat-stress-measures-for-outdoor-work` | Policy page | Deterministic safety rules | Rules must be versioned by effective date |
| MOM heat-stress FAQ | `https://www.mom.gov.sg/heat-stress-measures-for-outdoor-work/faqs-on-heat-stress-measures-for-outdoor-work` | Policy FAQ | Confirms breaks are continuous and hourly | Keep exact scope: heavy physical outdoor work |

Anonymous data.gov.sg access is allowed for testing. The published limit for v2 real-time APIs is 6 requests per 10 seconds without a key, 12 with a development key, and 30 with a production key. Implement caching, backoff, and last-known-good provenance.

## Research and impact sources

| Source | What it supports | Safe claim boundary |
|---|---|---|
| Meteorological Service Singapore 2025 climate summary | Record 35.0 degree C WBGT, 29 high-heat days, warming trend | Climate observations, not a measurement of HeatShift's effect |
| NUS Medicine Project HeatSafe | Local construction-worker and economic productivity evidence | Preserve sample sizes; economy-wide losses cover four sectors |
| MOM heat-illness parliamentary answer | 24 reported non-fatal cases in 2021-2025, 22 outdoor | Reported cases only; do not infer prevalence |
| MOM Workplace Safety and Health Report 2025 | Construction and national injury context | Not heat-specific |
| MSS Annual Climate Assessment 2023 | Future high-heat-day projections | Always label as scenario projections with uncertainty |

## Inputs that should remain synthetic in the MVP

- Worker names and identity numbers
- Diagnoses, medication, pregnancy, body measurements, and biometric streams
- Commercially confidential rosters and payroll
- Active construction schedules, costs, and dependencies
- Supervisor approval identities used in a public demo

Use pseudonymous IDs and a minimal operational schema. A worker can be marked as needing heat redeployment without storing the medical reason. Every synthetic field should be labeled `source: synthetic_demo` so judges can distinguish it from live official data.

## Data-quality policy

1. Preserve raw responses unchanged.
2. Normalize into a typed schema without deleting the station, observation time, or source URL.
3. Treat `NA`, missing stations, stale timestamps, network failures, and unexpected schemas as explicit quality states.
4. Select the nearest valid station by geodesic distance, but display that distance and whether an on-site meter is legally required.
5. Fall back only to a cached, timestamped reading; never silently fabricate a live value.
6. Do not let the LLM turn descriptive guidance into a different threshold. The deterministic rule engine owns compliance.
7. Log the input hash, ruleset ID, selected station, schedule validator result, and human approval state in every Decision Certificate.

