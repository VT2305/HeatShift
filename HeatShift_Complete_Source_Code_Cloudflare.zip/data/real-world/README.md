# HeatShift real-world data pack

Collected on 4 September 2026 (Singapore time) for the HeatShift Agentic AI hackathon prototype.

## What is included

- `raw/wbgt_latest.json`: live NEA WBGT station observations from data.gov.sg.
- `raw/wbgt_record_day_2025-10-31.json`: all 96 fifteen-minute observation windows for 31 October 2025, the day Singapore recorded its highest reported WBGT.
- `raw/air_temperature_latest.json`, `relative_humidity_latest.json`, `wind_speed_latest.json`, and `rainfall_latest.json`: supporting live environmental observations.
- `raw/two_hour_forecast_latest.json` and `twenty_four_hour_forecast_latest.json`: live forecast responses.
- `normalized/*.csv`: flattened station-level versions suitable for pandas, DuckDB, a database seed, or automated evaluation.
- `mom_heat_rules_2026.json`: machine-readable safety rules and implementation constraints transcribed from MOM sources.
- `impact_evidence.json`: sourced figures for the problem statement and impact slides.
- `source_catalog.md`: provenance, limitations, and the safe way to use each source.

## Verified snapshot summary

The live WBGT snapshot at 22:15 SGT contained 30 stations. The maximum was 26.9 degrees C, reported at Hougang Stadium and Sakra Road (Jurong Island), and was classified Low.

The 31 October 2025 replay dataset contains:

- 96 fifteen-minute periods;
- 15 WBGT stations per period;
- 1,440 station-time rows;
- 1,439 numeric observations and one `NA` value;
- 1,235 observations below 31 degrees C;
- 179 observations from 31 to below 33 degrees C;
- 25 observations at or above 33 degrees C; and
- a maximum of 35.0 degrees C at Sentosa Palawan Green at 12:15 SGT.

This gives HeatShift a real, reproducible heat-spike scenario for scheduling and safety tests.

## Critical implementation rule

Use the measured NEA WBGT value as the authoritative environmental input. Do not calculate or infer WBGT from air temperature and relative humidity. Singapore's Meteorological Service explicitly states that WBGT also depends on wind and radiant heat and is not interchangeable with air temperature.

The forecast APIs do not forecast WBGT. They may help the agent decide when to refresh or warn about uncertainty, but a forecast must never be presented as a measured or official future WBGT value.

## Data boundaries

Real public data is available for environmental conditions, safety rules, climate history, and sector-level impact. Public worker rosters, medical details, task dependencies, and active construction schedules are neither necessary nor appropriate for the MVP. Those inputs should remain synthetic, use pseudonymous worker IDs, and record only operational flags such as `acclimatisation_day`, `fit_for_outdoor_work`, and `heat_redeployment_required`.

## Recommended evaluation use

1. Live-monitoring test: load `wbgt_latest.csv`; expect a normal monitoring decision at the captured nighttime conditions.
2. Record-heat replay: stream `wbgt_record_day_2025-10-31.csv` in timestamp order.
3. At 31 degrees C, verify hourly hydration and cooler-period rescheduling advice.
4. At 32 degrees C, verify a continuous minimum 10-minute hourly break for heavy physical outdoor work.
5. At 33 degrees C, verify a continuous minimum 15-minute hourly break and vulnerable-worker redeployment.
6. Require the schedule validator to pass before a recommendation reaches human approval.
7. Preserve the source timestamp, station, raw value, rule version, tool trace, and approval state in the Decision Certificate.

## Refreshing the data

The official public endpoints used for this pack are listed in `source_catalog.md`. Public testing does not require an API key, but data.gov.sg applies lower anonymous rate limits. A development API key should be stored only in a backend secret or AWS secret store, never in frontend code or committed files.

