import importlib.util
import os
import sys
import types
import unittest
from pathlib import Path


class FakeClient:
    pass


fake_boto3 = types.SimpleNamespace(resource=lambda *_args, **_kwargs: FakeClient(), client=lambda *_args, **_kwargs: FakeClient())
sys.modules.setdefault("boto3", fake_boto3)
botocore = types.ModuleType("botocore")
exceptions = types.ModuleType("botocore.exceptions")
exceptions.ClientError = RuntimeError
sys.modules.setdefault("botocore", botocore)
sys.modules.setdefault("botocore.exceptions", exceptions)
os.environ["BEDROCK_ENABLED"] = "false"

spec = importlib.util.spec_from_file_location("heatshift_agent", Path(__file__).with_name("app.py"))
agent = importlib.util.module_from_spec(spec)
assert spec and spec.loader
spec.loader.exec_module(agent)


class SafetyEngineTests(unittest.TestCase):
    def test_mom_heavy_work_thresholds(self):
        self.assertEqual(agent.minimum_rest_minutes(31.9, "heavy"), 0)
        self.assertEqual(agent.minimum_rest_minutes(32.0, "heavy"), 10)
        self.assertEqual(agent.minimum_rest_minutes(33.0, "heavy"), 15)

    def test_record_heat_plan_passes_all_guardrails(self):
        plan = agent.build_plan(35.0)
        validation = agent.validate_plan(35.0, plan)
        self.assertTrue(validation["valid"])
        self.assertTrue(all(item["restMinutes"] >= 15 for item in plan))
        self.assertTrue(any(item["action"] == "redeploy_vulnerable" for item in plan))

    def test_duplicate_rest_capacity_is_rejected(self):
        plan = agent.build_plan(35.0)
        plan[1]["restBay"] = plan[0]["restBay"]
        self.assertFalse(agent.validate_plan(35.0, plan)["valid"])


if __name__ == "__main__":
    unittest.main(verbosity=2)
