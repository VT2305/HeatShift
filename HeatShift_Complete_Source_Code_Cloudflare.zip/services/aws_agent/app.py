"""HeatShift AWS Sandbox control plane.

The model may explain a plan. It never owns safety thresholds, validation,
approval, persistence, or notification activation.
"""

from __future__ import annotations

import hashlib
import json
import os
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Any

import boto3
from botocore.exceptions import ClientError

TABLE_NAME = os.environ.get("TABLE_NAME", "heatshift-operations")
NOTIFICATION_TOPIC_ARN = os.environ.get("NOTIFICATION_TOPIC_ARN", "")
MODEL_ID = os.environ.get("MODEL_ID", "amazon.nova-micro-v1:0")
BEDROCK_ENABLED = os.environ.get("BEDROCK_ENABLED", "false").lower() == "true"
RULESET_ID = "SG_MOM_OUTDOOR_HEAT_2026_09_04"

dynamodb = boto3.resource("dynamodb")
sns = boto3.client("sns")
bedrock = boto3.client("bedrock-runtime")

CREWS = [
    {"id": "CR-014", "name": "Rebar Alpha", "workers": 24, "intensity": "heavy", "vulnerable": 0, "acclimatised": True, "bay": "Cool Bay 03"},
    {"id": "CR-021", "name": "Concrete Bravo", "workers": 31, "intensity": "heavy", "vulnerable": 2, "acclimatised": True, "bay": "Cool Bay 07"},
    {"id": "CR-033", "name": "Facade Delta", "workers": 18, "intensity": "moderate", "vulnerable": 1, "acclimatised": True, "bay": "North Welfare Hub"},
    {"id": "CR-041", "name": "Logistics Echo", "workers": 16, "intensity": "heavy", "vulnerable": 0, "acclimatised": False, "bay": "West Rest Pod"},
]


def minimum_rest_minutes(wbgt: float, intensity: str) -> int:
    if intensity == "heavy":
        return 15 if wbgt >= 33 else 10 if wbgt >= 32 else 0
    return 10 if wbgt >= 33 else 5 if wbgt >= 32 else 0


def build_plan(wbgt: float) -> list[dict[str, Any]]:
    plan = []
    for index, crew in enumerate(CREWS):
        rest = max(minimum_rest_minutes(wbgt, crew["intensity"]), 15 if crew["vulnerable"] else 0)
        minute_of_day = 13 * 60 + 45 + index * 5
        start_time = f"{minute_of_day // 60:02d}:{minute_of_day % 60:02d}:00+08:00"
        plan.append({
            "crewId": crew["id"],
            "crew": crew["name"],
            "workers": crew["workers"],
            "action": "redeploy_vulnerable" if crew["vulnerable"] else "continuous_cool_rest",
            "restMinutes": rest,
            "restBay": crew["bay"],
            "startsAt": start_time,
        })
    return plan


def validate_plan(wbgt: float, plan: list[dict[str, Any]]) -> dict[str, Any]:
    required = 15 if wbgt >= 33 else 10 if wbgt >= 32 else 0
    checks = {
        "minimumRest": all(item["restMinutes"] >= required for item in plan if item["action"] == "continuous_cool_rest"),
        "continuousBlocks": all(item["restMinutes"] > 0 for item in plan),
        "uniqueRestCapacity": len({item["restBay"] for item in plan}) == len(plan),
        "vulnerableRedeployment": any(item["action"] == "redeploy_vulnerable" for item in plan),
        "humanApprovalRequired": True,
    }
    return {"valid": all(checks.values()), "checks": checks, "rulesetId": RULESET_ID}


def model_explanation(wbgt: float, plan: list[dict[str, Any]]) -> str:
    fallback = "Four protected rotations reduce exposure while preserving the milestone. Deterministic rules, not the model, set every minimum."
    if not BEDROCK_ENABLED:
        return fallback
    prompt = {
        "wbgt": wbgt,
        "rulesetId": RULESET_ID,
        "validatedPlan": plan,
        "instruction": "Explain this already-validated work-rest plan in at most 60 words. Do not add, remove, or change any safety rule or schedule value.",
    }
    try:
        response = bedrock.converse(
            modelId=MODEL_ID,
            messages=[{"role": "user", "content": [{"text": json.dumps(prompt)}]}],
            inferenceConfig={"maxTokens": 120, "temperature": 0.1, "topP": 0.9},
        )
        return response["output"]["message"]["content"][0]["text"]
    except (ClientError, KeyError, IndexError):
        return fallback


def handler(event: dict[str, Any], _context: Any) -> dict[str, Any]:
    request = event.get("requestContext", {}).get("http", {})
    method = request.get("method", "GET")
    path = request.get("path", "/")

    if method == "GET" and path.endswith("/health"):
        return response(200, {"status": "ok", "rulesetId": RULESET_ID, "humanApprovalRequired": True})

    claims = event.get("requestContext", {}).get("authorizer", {}).get("jwt", {}).get("claims", {})
    subject = claims.get("sub")
    if not subject:
        return response(401, {"error": "authentication_required"})

    if method == "POST" and path.endswith("/agent/run"):
        return create_agent_run(event, subject)
    if method == "POST" and path.endswith("/approve"):
        run_id = path.rstrip("/").split("/")[-2]
        return approve_run(event, subject, run_id)
    return response(404, {"error": "not_found"})


def create_agent_run(event: dict[str, Any], subject: str) -> dict[str, Any]:
    body = parse_body(event)
    site_id = body.get("siteId")
    wbgt = body.get("wbgt")
    observed_at = body.get("observationTime")
    if not isinstance(site_id, str) or not site_id.startswith("SITE-") or not isinstance(wbgt, (int, float)) or not 20 <= wbgt <= 50 or not isinstance(observed_at, str):
        return response(400, {"error": "invalid_request"})
    plan = build_plan(float(wbgt))
    validation = validate_plan(float(wbgt), plan)
    if not validation["valid"]:
        return response(422, {"error": "guardrail_validation_failed", "validation": validation})
    run_id = f"HS-{uuid.uuid4().hex[:12].upper()}"
    now = utc_now()
    item = {
        "pk": f"SITE#{site_id}", "sk": f"RUN#{run_id}", "entityType": "agent_run", "runId": run_id,
        "siteId": site_id, "wbgt": Decimal(str(wbgt)), "observationTime": observed_at,
        "status": "awaiting_approval", "plan": plan, "validation": validation,
        "explanation": model_explanation(float(wbgt), plan), "createdBy": subject, "createdAt": now,
    }
    table().put_item(Item=item, ConditionExpression="attribute_not_exists(pk) AND attribute_not_exists(sk)")
    return response(201, json_safe(item))


def approve_run(event: dict[str, Any], subject: str, run_id: str) -> dict[str, Any]:
    body = parse_body(event)
    site_id = body.get("siteId")
    rationale = body.get("rationale", "")
    idempotency_key = header(event, "idempotency-key")
    if not isinstance(site_id, str) or not isinstance(rationale, str) or not 8 <= len(rationale) <= 600 or len(idempotency_key) < 8:
        return response(400, {"error": "invalid_request"})
    result = table().get_item(Key={"pk": f"SITE#{site_id}", "sk": f"RUN#{run_id}"}, ConsistentRead=True)
    run = result.get("Item")
    if not run:
        return response(404, {"error": "agent_run_not_found"})
    validation = validate_plan(float(run["wbgt"]), run["plan"])
    if not validation["valid"]:
        return response(422, {"error": "guardrail_validation_failed"})
    now = utc_now()
    decision_id = f"DEC-{uuid.uuid4().hex[:10].upper()}"
    certificate = {"decisionId": decision_id, "runId": run_id, "siteId": site_id, "approvedBy": subject, "approvedAt": now, "plan": run["plan"], "validation": validation}
    digest = hashlib.sha256(json.dumps(certificate, sort_keys=True).encode()).hexdigest()
    try:
        table().update_item(
            Key={"pk": run["pk"], "sk": run["sk"]},
            UpdateExpression="SET #status = :approved, decisionId = :decision, approvedBy = :actor, approvedAt = :at, certificateHash = :digest",
            ConditionExpression="#status = :pending",
            ExpressionAttributeNames={"#status": "status"},
            ExpressionAttributeValues={":approved": "approved", ":pending": "awaiting_approval", ":decision": decision_id, ":actor": subject, ":at": now, ":digest": digest},
        )
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
            return response(409, {"error": "agent_run_not_actionable"})
        raise
    if NOTIFICATION_TOPIC_ARN:
        sns.publish(TopicArn=NOTIFICATION_TOPIC_ARN, Message=json.dumps(certificate), MessageAttributes={"eventType": {"DataType": "String", "StringValue": "heatshift.plan.approved"}})
    return response(201, {**certificate, "certificateHash": digest, "notificationsQueued": True})


def table():
    return dynamodb.Table(TABLE_NAME)


def parse_body(event: dict[str, Any]) -> dict[str, Any]:
    try:
        return json.loads(event.get("body") or "{}")
    except json.JSONDecodeError:
        return {}


def header(event: dict[str, Any], name: str) -> str:
    headers = {key.lower(): value for key, value in (event.get("headers") or {}).items()}
    return headers.get(name.lower(), "")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def json_safe(value: Any) -> Any:
    return json.loads(json.dumps(value, default=lambda item: float(item) if isinstance(item, Decimal) else str(item)))


def response(status: int, body: dict[str, Any]) -> dict[str, Any]:
    return {"statusCode": status, "headers": {"content-type": "application/json", "cache-control": "no-store", "x-content-type-options": "nosniff"}, "body": json.dumps(json_safe(body), ensure_ascii=False)}
