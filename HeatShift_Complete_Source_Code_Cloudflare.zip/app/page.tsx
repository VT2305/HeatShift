'use client';

import { type ReactNode, useCallback, useEffect, useMemo, useState } from 'react';
import {
  Activity,
  AlertTriangle,
  ArrowRight,
  Bell,
  Bot,
  Building2,
  CalendarClock,
  Check,
  CheckCircle2,
  ChevronDown,
  CircleDot,
  ClipboardCheck,
  Command,
  Database,
  Download,
  Droplets,
  FileCheck2,
  Globe2,
  HardHat,
  LayoutDashboard,
  Languages,
  LockKeyhole,
  Map,
  MapPin,
  Menu,
  MessageCircleWarning,
  Pause,
  Play,
  Radio,
  RefreshCw,
  ShieldCheck,
  Sparkles,
  ThermometerSun,
  Users,
  Waves,
  Workflow,
} from 'lucide-react';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from '@/components/ui/sidebar';
import { buildSafePlan, demoCrews, validatePlan } from '@/lib/safety-engine';

const nav = [
  [LayoutDashboard, 'Portfolio'],
  [Command, 'Command center'],
  [Map, 'Live map'],
  [CalendarClock, 'Schedule'],
  [Users, 'Workers'],
  [Bell, 'Notifications'],
  [ClipboardCheck, 'Decisions'],
  [Play, 'Replay lab'],
  [FileCheck2, 'Evidence'],
] as const;

const agentSteps = [
  ['Sense', '15 stations synced'],
  ['Check', 'Confidence 98.4%'],
  ['Assess', '11 crews affected'],
  ['Plan', '4 safe changes found'],
  ['Validate', 'Rules + capacity'],
  ['Approve', 'Supervisor gate'],
  ['Notify', '5 languages'],
] as const;

const heatPoints = [32.6, 33.2, 33.5, 34.1, 34, 32.5, 31.8, 31.4, 33, 35, 33.6, 32.8, 33.3, 33.5, 33.4, 33.7];

type ViewName = (typeof nav)[number][1];
type FlowState = 'ready' | 'running' | 'review' | 'approved';

const workerMessages = {
  English: 'Your 15-minute cool rest is approved. Report to Cool Bay 03 at 13:45.',
  Tamil: 'உங்கள் 15 நிமிட குளிர் ஓய்வு அங்கீகரிக்கப்பட்டது. 13:45க்கு Cool Bay 03க்கு செல்லவும்.',
  Bengali: 'আপনার ১৫ মিনিটের শীতল বিরতি অনুমোদিত হয়েছে। ১৩:৪৫-এ Cool Bay 03-এ যান।',
  Mandarin: '您的15分钟降温休息已获批准。请在13:45前往 Cool Bay 03。',
  Malay: 'Rehat sejuk 15 minit anda diluluskan. Pergi ke Cool Bay 03 pada 13:45.',
} as const;

function useHeatShiftTools({
  flowState,
  setActiveView,
  startPlanReview,
  setReviewOpen,
}: {
  flowState: FlowState;
  setActiveView: (view: ViewName) => void;
  startPlanReview: () => void;
  setReviewOpen: (open: boolean) => void;
}) {
  useEffect(() => {
    const context = typeof document === 'undefined' ? undefined : document.modelContext;
    if (!context?.registerTool) return;
    const lifecycle = new AbortController();
    const register = (tool: WebMcpTool) => {
      try { void Promise.resolve(context.registerTool(tool, { signal: lifecycle.signal })).catch(() => undefined); } catch { /* Unsupported implementations stay non-blocking. */ }
    };
    const noArguments = (input: unknown) => {
      if (input !== undefined && input !== null && (typeof input !== 'object' || Object.keys(input as object).length > 0)) throw new Error('This action does not accept arguments.');
    };

    register({
      name: 'read_heatshift_status',
      title: 'Read HeatShift status',
      description: 'Read the current record-heat risk and approval state without changing the interface.',
      inputSchema: { type: 'object', properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: true, untrustedContentHint: false },
      execute(input) {
        noArguments(input);
        return { wbgtC: 35, station: 'S142', observedAt: '2025-10-31T12:15:00+08:00', risk: 'critical', flowState, humanApprovalRequired: true };
      },
    });
    register({
      name: 'start_record_heat_replay',
      title: 'Start record-heat replay',
      description: 'Open the replay lab and start the preserved 31 October 2025 WBGT event.',
      inputSchema: { type: 'object', properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      async execute(input) {
        noArguments(input);
        setActiveView('Replay lab');
        startPlanReview();
        await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
        return { started: true, dataset: 'NEA WBGT 2025-10-31', nextGate: 'supervisor_review' };
      },
    });
    register({
      name: 'open_supervisor_plan_review',
      title: 'Open supervisor review',
      description: 'Open the validated plan for a human supervisor. This tool cannot approve the plan.',
      inputSchema: { type: 'object', properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      async execute(input) {
        noArguments(input);
        if (flowState !== 'review' && flowState !== 'approved') throw new Error('A validated plan is not ready for review.');
        setActiveView('Decisions');
        setReviewOpen(true);
        await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
        return { opened: true, approvalPerformed: false, state: flowState };
      },
    });
    register({
      name: 'open_worker_notification',
      title: 'Open worker notification',
      description: 'Open the multilingual worker notification after a supervisor has approved the plan.',
      inputSchema: { type: 'object', properties: {}, additionalProperties: false },
      annotations: { readOnlyHint: false, untrustedContentHint: false },
      async execute(input) {
        noArguments(input);
        if (flowState !== 'approved') throw new Error('No approved worker notification is available.');
        setActiveView('Notifications');
        await new Promise<void>((resolve) => requestAnimationFrame(() => resolve()));
        return { opened: true, languages: Object.keys(workerMessages) };
      },
    });
    return () => lifecycle.abort();
  }, [flowState, setActiveView, setReviewOpen, startPlanReview]);
}

export default function Home() {
  const [activeView, setActiveView] = useState<ViewName>('Command center');
  const [flowState, setFlowState] = useState<FlowState>('ready');
  const [agentPhase, setAgentPhase] = useState(3);
  const [reviewOpen, setReviewOpen] = useState(false);
  const [language, setLanguage] = useState<keyof typeof workerMessages>('English');
  const [workerResponse, setWorkerResponse] = useState<'received' | 'needs_help' | 'cannot_comply' | null>(null);
  const [runId, setRunId] = useState('HS-251031-042');
  const [decisionId, setDecisionId] = useState('DEC-PENDING');
  const [certificateHash, setCertificateHash] = useState('pending supervisor approval');
  const plan = useMemo(() => buildSafePlan(35, demoCrews), []);
  const validation = useMemo(() => validatePlan(35, plan), [plan]);
  const linePoints = heatPoints
    .map((point, index) => `${24 + index * (473 / (heatPoints.length - 1))},${132 - (point - 31) * 22}`)
    .join(' ');

  useEffect(() => {
    if (flowState !== 'running') return;
    const timer = window.setInterval(() => {
      setAgentPhase((phase) => {
        if (phase >= 4) {
          window.clearInterval(timer);
          setFlowState('review');
          setReviewOpen(true);
          return 4;
        }
        return phase + 1;
      });
    }, 620);
    return () => window.clearInterval(timer);
  }, [flowState]);

  const startPlanReview = useCallback(() => {
    setFlowState('running');
    setAgentPhase(0);
    setWorkerResponse(null);
    void fetch('/api/agent/run', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ siteId: 'SITE-JID-01', wbgt: 35, observationTime: '2025-10-31T12:15:00+08:00' }),
    }).then(async (response) => {
      if (!response.ok) return;
      const data = await response.json() as { id?: string };
      if (data.id) setRunId(data.id);
    }).catch(() => undefined);
  }, []);

  async function approvePlan() {
    setFlowState('approved');
    setAgentPhase(6);
    setReviewOpen(false);
    const fallbackDecisionId = `DEC-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
    setDecisionId(fallbackDecisionId);
    setCertificateHash(`sha256:${crypto.randomUUID().replaceAll('-', '')}`);
    try {
      const response = await fetch('/api/decisions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Idempotency-Key': crypto.randomUUID() },
        body: JSON.stringify({ agentRunId: runId, action: 'approved', rationale: 'Approve validated rotations to reduce high-heat exposure while preserving the concrete milestone.' }),
      });
      if (response.ok) {
        const data = await response.json() as { decision?: { id?: string; certificateHash?: string } };
        if (data.decision?.id) setDecisionId(data.decision.id);
        if (data.decision?.certificateHash) setCertificateHash(`sha256:${data.decision.certificateHash}`);
      }
    } catch { /* The interface remains usable if local persistence is unavailable. */ }
    window.setTimeout(() => setActiveView('Notifications'), 420);
  }

  function agentStepStatus(index: number) {
    if (flowState === 'approved') return 'done';
    if (flowState === 'review') return index <= 4 ? 'done' : index === 5 ? 'active' : 'queued';
    if (flowState === 'running') return index < agentPhase ? 'done' : index === agentPhase ? 'active' : 'queued';
    return index < 3 ? 'done' : index === 3 ? 'active' : 'queued';
  }

  useHeatShiftTools({ flowState, setActiveView, startPlanReview, setReviewOpen });

  return (
    <SidebarProvider defaultOpen>
      <Sidebar collapsible="icon" className="border-r border-white/8">
        <SidebarHeader className="h-[76px] justify-center border-b border-white/8 px-4">
          <div className="flex items-center gap-3 overflow-hidden">
            <div className="logo-mark" aria-hidden="true">
              <Waves className="size-5" />
            </div>
            <div className="min-w-0 group-data-[collapsible=icon]:hidden">
              <p className="truncate text-[1.02rem] font-semibold tracking-[-0.03em] text-white">HeatShift</p>
              <p className="truncate text-xs text-slate-400">Safety operations</p>
            </div>
          </div>
        </SidebarHeader>
        <SidebarContent className="px-2 py-4">
          <SidebarGroup>
            <SidebarGroupLabel className="px-3 text-xs font-medium uppercase tracking-[0.12em] text-slate-500">
              Operations
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu className="gap-1">
                {nav.map(([Icon, label]) => (
                  <SidebarMenuItem key={label}>
                    <SidebarMenuButton
                      isActive={activeView === label}
                      tooltip={label}
                      onClick={() => setActiveView(label)}
                      className="h-10 rounded-lg px-3 text-slate-400 hover:bg-white/5 hover:text-white data-[active=true]:bg-cyan-400/10 data-[active=true]:font-medium data-[active=true]:text-cyan-300"
                    >
                      <Icon className="size-[18px]" />
                      <span>{label}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        </SidebarContent>
        <SidebarFooter className="border-t border-white/8 p-3">
          <div className="flex items-center gap-3 rounded-xl bg-white/[0.035] p-2.5 group-data-[collapsible=icon]:justify-center group-data-[collapsible=icon]:p-2">
            <div className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-violet-400/12 text-violet-300">
              <ShieldCheck className="size-4" />
            </div>
            <div className="min-w-0 group-data-[collapsible=icon]:hidden">
              <p className="truncate text-sm font-medium text-slate-200">Safety supervisor</p>
              <p className="truncate text-xs text-slate-500">Human approval required</p>
            </div>
          </div>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset className="min-w-0 bg-background">
        <header className="topbar">
          <div className="flex min-w-0 items-center gap-3">
            <SidebarTrigger className="text-slate-400 hover:bg-white/5 hover:text-white">
              <Menu className="size-5" />
            </SidebarTrigger>
            <div className="hidden h-7 w-px bg-white/8 sm:block" />
            <button className="site-selector" type="button">
              <Building2 className="size-4 text-cyan-300" />
              <span className="truncate">Jurong Innovation District</span>
              <ChevronDown className="size-4 text-slate-500" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <Badge variant="outline" className="hidden border-emerald-400/20 bg-emerald-400/8 px-2.5 py-1 text-emerald-300 md:flex">
              <Radio className="mr-1 size-3.5" /> Live sensors
            </Badge>
            <Badge variant="outline" className="hidden border-white/10 bg-white/[0.035] px-2.5 py-1 font-mono text-slate-300 lg:flex">
              12s fresh
            </Badge>
            <button className="icon-button" type="button" aria-label="View notifications" onClick={() => setActiveView('Notifications')}>
              <Bell className="size-[18px]" />
              {flowState === 'approved' && <span className="notification-dot" />}
            </button>
            <button className="avatar-button" type="button" aria-label="Open account menu">LS</button>
          </div>
        </header>

        <main className="workspace">
          {activeView === 'Command center' ? <>
          <section className="command-heading" aria-labelledby="command-title">
            <div>
              <div className="eyebrow-row">
                <span>COMMAND CENTER</span>
                <span className="eyebrow-separator" />
                <span className="text-slate-500">31 Oct 2025 · 13:45 SGT</span>
              </div>
              <h1 id="command-title">Heat exposure is climbing across the west yard.</h1>
              <p>HeatShift found a safer sequence before the next crew rotation.</p>
            </div>
            <div className="flex items-center gap-2 self-start">
              <Button variant="outline" onClick={() => setActiveView('Replay lab')} className="border-white/10 bg-white/[0.035] text-slate-200 hover:bg-white/8 hover:text-white">
                <RefreshCw className="size-4" /> Replay event
              </Button>
              <Button className="replan-button" onClick={flowState === 'review' ? () => setReviewOpen(true) : startPlanReview} disabled={flowState === 'running'}>
                {flowState === 'running' ? <Activity className="size-4 animate-pulse" /> : <Sparkles className="size-4" />}
                {flowState === 'approved' ? 'Plan approved' : flowState === 'running' ? 'Agent working…' : 'Review safe plan'}
              </Button>
            </div>
          </section>

          <div className="command-grid">
            <section className="main-stack" aria-label="Site risk overview">
              <article className="risk-hero">
                <div className="risk-orbit" aria-hidden="true">
                  <span className="orbit orbit-one" />
                  <span className="orbit orbit-two" />
                  <span className="orbit-center" />
                </div>
                <div className="risk-copy">
                  <div className="flex items-center gap-2">
                    <Badge className="border border-orange-400/20 bg-orange-400/10 text-orange-200 hover:bg-orange-400/10">
                      HIGH HEAT
                    </Badge>
                    <span className="text-sm text-slate-400">Verified observation</span>
                  </div>
                  <div className="mt-6 flex items-end gap-3">
                    <span className="font-mono text-[clamp(3.6rem,6vw,5.4rem)] font-medium leading-[0.84] tracking-[-0.08em] text-white">35.0</span>
                    <span className="mb-1 text-xl font-medium text-slate-400">°C WBGT</span>
                  </div>
                  <p className="mt-5 max-w-xl text-base leading-7 text-slate-300">
                    The record-high reading is now affecting <strong className="font-medium text-white">11 outdoor crews</strong>. A validated plan can lower projected high-heat exposure by <strong className="font-medium text-emerald-300">38%</strong> without delaying concrete works.
                  </p>
                  <div className="mt-7 grid grid-cols-3 gap-3">
                    <Metric label="Workers in scope" value="186" detail="11 crews" />
                    <Metric label="Rest capacity" value="72%" detail="18 bays open" />
                    <Metric label="Data confidence" value="98.4%" detail="15 / 15 stations" />
                  </div>
                </div>
              </article>

              <article className="panel chart-panel">
                <div className="panel-heading">
                  <div>
                    <p className="panel-kicker">HEAT TRACE</p>
                    <h2>Observed WBGT · 10:00–13:45</h2>
                  </div>
                  <div className="legend">
                    <span><i className="legend-line bg-cyan-300" /> Observed</span>
                    <span><i className="legend-line border-t border-dashed border-orange-300 bg-transparent" /> 33°C rule</span>
                  </div>
                </div>
                <div className="chart-wrap">
                  <svg viewBox="0 0 520 158" aria-label="At Sentosa Palawan Green, WBGT peaked at 35 degrees at 12:15 PM on 31 October 2025">
                    <defs>
                      <linearGradient id="traceFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#67e8f9" stopOpacity="0.22" />
                        <stop offset="100%" stopColor="#67e8f9" stopOpacity="0" />
                      </linearGradient>
                    </defs>
                    {[34, 74, 114].map((y) => <line key={y} x1="24" x2="497" y1={y} y2={y} stroke="rgba(148,163,184,.13)" />)}
                    <line x1="24" x2="497" y1="88" y2="88" stroke="#fdba74" strokeDasharray="5 7" opacity=".72" />
                    <polygon points={`${linePoints} 497,142 24,142`} fill="url(#traceFill)" />
                    <polyline points={linePoints} fill="none" stroke="#67e8f9" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round" />
                    <circle cx="308" cy="44" r="5" fill="#07111f" stroke="#fff" strokeWidth="2" />
                    <text x="315" y="37" fill="#f8fafc" fontSize="12" fontFamily="var(--font-geist-mono)">35.0°</text>
                    <text x="24" y="155" fill="#64748b" fontSize="11">10:00</text>
                    <text x="276" y="155" fill="#64748b" fontSize="11">12:00</text>
                    <text x="462" y="155" fill="#64748b" fontSize="11">13:45</text>
                  </svg>
                </div>
              </article>
            </section>

            <aside className="agent-rail" aria-labelledby="agent-title">
              <div className="agent-title-row">
                <div className="agent-icon"><Bot className="size-5" /></div>
                <div>
                  <p className="panel-kicker text-violet-300">AGENT RUN</p>
                  <h2 id="agent-title">{runId}</h2>
                </div>
                <span className="ml-auto flex items-center gap-1.5 text-sm text-violet-200">
                  <CircleDot className={flowState === 'approved' ? 'size-3.5' : 'size-3.5 animate-pulse'} />
                  {flowState === 'approved' ? 'Complete' : flowState === 'review' ? 'Awaiting approval' : 'Planning'}
                </span>
              </div>

              <div className="agent-steps">
                {agentSteps.map(([label, detail], index) => {
                  const status = agentStepStatus(index);
                  return <div className={`agent-step ${status}`} key={label}>
                    <div className="step-marker">
                      {status === 'done' ? <Check className="size-3.5" /> : index + 1}
                    </div>
                    <div className="min-w-0">
                      <p>{label}</p>
                      <span>{detail}</span>
                    </div>
                    {status === 'active' && <Activity className="ml-auto size-4 text-violet-300" />}
                  </div>;
                })}
              </div>

              <div className="constraint-card">
                <div className="flex items-center justify-between gap-3">
                  <span className="flex items-center gap-2 text-sm font-medium text-slate-200"><ShieldCheck className="size-4 text-emerald-300" /> Guardrails</span>
                  <span className="font-mono text-xs text-emerald-300">12 / 12</span>
                </div>
                <Progress value={100} className="mt-3 h-1.5 bg-white/8 [&>div]:bg-emerald-400" />
                <p className="mt-3 text-sm leading-6 text-slate-400">No plan can activate until deterministic checks pass and a supervisor approves it.</p>
              </div>
            </aside>
          </div>
          </> : (
            <FeatureView
              view={activeView}
              flowState={flowState}
              language={language}
              onLanguageChange={setLanguage}
              workerResponse={workerResponse}
              onWorkerResponse={setWorkerResponse}
              onOpenDecision={() => setReviewOpen(true)}
              onStartReplay={startPlanReview}
              decisionId={decisionId}
              certificateHash={certificateHash}
              plan={plan}
              onNavigate={setActiveView}
            />
          )}
        </main>
        <DecisionReviewDialog
          open={reviewOpen}
          onOpenChange={setReviewOpen}
          onApprove={approvePlan}
          plan={plan}
          validation={validation}
        />
      </SidebarInset>
    </SidebarProvider>
  );
}

function Metric({ label, value, detail }: { label: string; value: string; detail: string }) {
  return (
    <div className="metric">
      <span>{label}</span>
      <strong>{value}</strong>
      <small>{detail}</small>
    </div>
  );
}

type FeatureViewProps = {
  view: ViewName;
  flowState: FlowState;
  language: keyof typeof workerMessages;
  onLanguageChange: (language: keyof typeof workerMessages) => void;
  workerResponse: 'received' | 'needs_help' | 'cannot_comply' | null;
  onWorkerResponse: (response: 'received' | 'needs_help' | 'cannot_comply') => void;
  onOpenDecision: () => void;
  onStartReplay: () => void;
  decisionId: string;
  certificateHash: string;
  plan: ReturnType<typeof buildSafePlan>;
  onNavigate: (view: ViewName) => void;
};

function FeatureView(props: FeatureViewProps) {
  const { view, flowState, plan, onNavigate } = props;
  if (view === 'Portfolio') return <PortfolioView onNavigate={onNavigate} />;
  if (view === 'Live map') return <LiveMapView />;
  if (view === 'Schedule') return <ScheduleView plan={plan} flowState={flowState} onOpenDecision={props.onOpenDecision} />;
  if (view === 'Workers') return <WorkersView />;
  if (view === 'Notifications') return <NotificationsView {...props} />;
  if (view === 'Decisions') return <DecisionsView flowState={flowState} decisionId={props.decisionId} onOpenDecision={props.onOpenDecision} onNavigate={onNavigate} />;
  if (view === 'Replay lab') return <ReplayView onStartReplay={props.onStartReplay} flowState={flowState} onNavigate={onNavigate} />;
  return <EvidenceView flowState={flowState} decisionId={props.decisionId} certificateHash={props.certificateHash} plan={plan} onNavigate={onNavigate} />;
}

function ViewHeading({ kicker, title, description, action }: { kicker: string; title: string; description: string; action?: ReactNode }) {
  return (
    <section className="view-heading">
      <div>
        <p className="eyebrow-row">{kicker}</p>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {action}
    </section>
  );
}

const portfolioSites = [
  ['Jurong Innovation District', 'Singapore West', 35.0, 'Critical', 186],
  ['Tuas Port Phase 2', 'Tuas', 33.8, 'High', 324],
  ['Punggol Digital District', 'Punggol', 33.5, 'High', 142],
  ['Changi T5 Enabling Works', 'Changi', 32.8, 'Caution', 278],
  ['Cross Island Line CR14', 'Turf City', 32.6, 'Caution', 204],
  ['Woodlands Health Campus', 'Woodlands', 31.9, 'Watch', 116],
  ['Jurong Region Line JRL5', 'Boon Lay', 31.7, 'Watch', 174],
  ['Tengah District Cooling', 'Tengah', 31.5, 'Watch', 98],
  ['Keppel South Central', 'HarbourFront', 31.2, 'Watch', 132],
  ['NSC Novena Package', 'Novena', 30.8, 'Stable', 156],
  ['Pasir Ris 8', 'Pasir Ris', 30.4, 'Stable', 88],
  ['Loyang Industrial Estate', 'Loyang', 29.9, 'Stable', 74],
] as const;

function PortfolioView({ onNavigate }: { onNavigate: (view: ViewName) => void }) {
  return (
    <>
      <ViewHeading
        kicker="PORTFOLIO · 12 ACTIVE SITES"
        title="Every heat decision, visible before it becomes an incident."
        description="2,072 workers across Singapore · observations normalised to a single safety ruleset."
        action={<Button className="replan-button" onClick={() => onNavigate('Command center')}><Command className="size-4" /> Open critical site</Button>}
      />
      <div className="portfolio-strip">
        <MetricCard icon={<HardHat />} label="Workers protected" value="2,072" detail="91 active crews" tone="cyan" />
        <MetricCard icon={<ThermometerSun />} label="Above 33°C" value="3 sites" detail="652 workers in scope" tone="orange" />
        <MetricCard icon={<Pause />} label="Awaiting approval" value="1 plan" detail="oldest 02:14" tone="violet" />
        <MetricCard icon={<CheckCircle2 />} label="Acknowledged today" value="94.6%" detail="1,127 confirmations" tone="green" />
      </div>
      <section className="panel data-table-panel">
        <div className="panel-heading table-panel-heading">
          <div><p className="panel-kicker">RANKED BY EXPOSURE</p><h2>Site risk board</h2></div>
          <Badge variant="outline" className="border-white/10 bg-white/[.03] text-slate-300">Updated 12s ago</Badge>
        </div>
        <Table>
          <TableHeader><TableRow><TableHead>Site</TableHead><TableHead>WBGT</TableHead><TableHead>Risk</TableHead><TableHead>Workers</TableHead><TableHead className="text-right">Action</TableHead></TableRow></TableHeader>
          <TableBody>
            {portfolioSites.map(([site, location, wbgt, risk, workers], index) => (
              <TableRow key={site} className={index === 0 ? 'bg-orange-400/[.035]' : ''}>
                <TableCell><div className="table-primary">{site}</div><div className="table-secondary"><MapPin className="size-3" />{location}</div></TableCell>
                <TableCell className="font-mono text-slate-200">{wbgt.toFixed(1)}°</TableCell>
                <TableCell><RiskPill risk={risk} /></TableCell>
                <TableCell className="font-mono text-slate-300">{workers}</TableCell>
                <TableCell className="text-right"><Button variant="ghost" size="sm" onClick={() => onNavigate(index === 0 ? 'Command center' : 'Live map')} className="text-slate-300 hover:bg-white/5 hover:text-white">Inspect <ArrowRight className="size-3.5" /></Button></TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </section>
    </>
  );
}

function MetricCard({ icon, label, value, detail, tone }: { icon: ReactNode; label: string; value: string; detail: string; tone: string }) {
  return (
    <article className={`metric-card tone-${tone}`}>
      <div className="metric-icon">{icon}</div>
      <div><p>{label}</p><strong>{value}</strong><span>{detail}</span></div>
    </article>
  );
}

function RiskPill({ risk }: { risk: string }) {
  return <span className={`risk-pill risk-${risk.toLowerCase()}`}><i />{risk}</span>;
}

function LiveMapView() {
  const mapPositions = [
    [27.1, 39.4], [16.2, 66.8], [59.3, 24.3], [72.8, 41.1],
    [42.3, 42.2], [40.8, 15.4], [29.0, 43.4], [32.6, 31.4],
    [46.0, 64.2], [49.0, 48.5], [65.2, 33.4], [68.6, 34.8],
  ] as const;
  const markers = portfolioSites.map(([name, location, wbgt, risk, workers], index) => ({ name, location, wbgt, risk, workers, x: mapPositions[index][0], y: mapPositions[index][1] }));
  return (
    <>
      <ViewHeading kicker="LIVE MAP" title="Risk follows the work, not the weather station." description="Site observations, task intensity and rest capacity are fused into one operational picture." />
      <div className="map-layout">
        <section className="panel risk-map" aria-label="Singapore map showing the geographic positions and heat risk of twelve active sites">
          <div className="map-grid" aria-hidden="true" />
          <div className="map-compass" aria-hidden="true"><span>N</span><i /></div>
          <div className="singapore-map-canvas">
            <svg className="map-boundary" viewBox="0 0 900 470" aria-labelledby="singapore-map-title">
              <title id="singapore-map-title">Singapore land boundary with district divisions</title>
            </svg>
            <span className="map-place place-tuas">Tuas</span>
            <span className="map-place place-woodlands">Woodlands</span>
            <span className="map-place place-city">City</span>
            <span className="map-place place-changi">Changi</span>
            <span className="map-place place-sentosa">Sentosa</span>
            {markers.map((marker, index) => (
              <button key={marker.name} className={`map-marker marker-${marker.risk.toLowerCase()}`} style={{ left: `${marker.x}%`, top: `${marker.y}%` }} aria-label={`${marker.name}, ${marker.wbgt} degrees WBGT, ${marker.risk} risk`}>
                <span>{index + 1}</span><div><strong>{marker.name}</strong><small>{marker.location} · {marker.wbgt.toFixed(1)}° WBGT</small></div>
              </button>
            ))}
          </div>
          <div className="map-legend" aria-label="Risk legend"><span><i className="critical" />Critical</span><span><i className="high" />High</span><span><i className="watch" />Watch</span><span><i className="stable" />Stable</span></div>
          <div className="source-ribbon"><Database className="size-4" /><span>Boundary: ELD · Heat: NEA / data.gov.sg</span><i />96 intervals · 15 stations · integrity verified</div>
        </section>
        <aside className="panel map-side-panel">
          <p className="panel-kicker">CRITICAL CLUSTER</p><h2>Western corridor</h2>
          <p className="mt-2 text-sm leading-6 text-slate-400">Three site zones share the same high-heat window while rest capacity remains uneven.</p>
          <div className="map-stat"><span>Peak WBGT</span><strong>35.0°C</strong></div>
          <div className="map-stat"><span>Workers exposed</span><strong>652</strong></div>
          <div className="map-stat"><span>Capacity gap</span><strong className="text-orange-300">26 places</strong></div>
          <div className="mt-5 rounded-xl border border-cyan-400/10 bg-cyan-400/[.035] p-4 text-sm leading-6 text-slate-300"><ShieldCheck className="mb-2 size-5 text-cyan-300" />Sensor distance is never treated as worker exposure. Task and zone context remain mandatory.</div>
        </aside>
      </div>
    </>
  );
}

function ScheduleView({ plan, flowState, onOpenDecision }: { plan: ReturnType<typeof buildSafePlan>; flowState: FlowState; onOpenDecision: () => void }) {
  return (
    <>
      <ViewHeading kicker="SCHEDULE" title="A schedule that can explain every movement." description="The original programme remains intact until validation and supervisor approval are complete." action={<Button className="replan-button" onClick={onOpenDecision}><ClipboardCheck className="size-4" /> {flowState === 'approved' ? 'View approved plan' : 'Review changes'}</Button>} />
      <section className="panel schedule-panel">
        <div className="schedule-scale"><span>13:30</span><span>13:45</span><span>14:00</span><span>14:15</span><span>14:30</span></div>
        {plan.map((item, index) => (
          <div className="schedule-row" key={item.crewId}>
            <div className="schedule-name"><strong>{item.crew}</strong><span>{item.crewId} · {demoCrews[index]?.workers ?? 18} workers</span></div>
            <div className="schedule-track">
              <span className="schedule-work" style={{ left: `${index * 5}%`, width: '86%' }}>Outdoor task</span>
              <span className="schedule-rest" style={{ left: `${22 + index * 13}%`, width: `${16 + item.restMinutes / 3}%` }}><Pause className="size-3" /> {item.restMinutes}m · {item.restBay}</span>
            </div>
          </div>
        ))}
        <div className="schedule-legend"><span><i className="bg-cyan-400/25" /> Outdoor work</span><span><i className="bg-emerald-400/35" /> Protected continuous rest</span><span className="ml-auto font-mono text-xs text-slate-500">constraint model v1.4</span></div>
      </section>
    </>
  );
}

function WorkersView() {
  return (
    <>
      <ViewHeading kicker="WORKFORCE" title="Protect people without exposing medical details." description="HeatShift schedules from minimum operational flags. Diagnoses, medications and pregnancy data never enter the agent." action={<Button variant="outline" className="border-white/10 bg-white/[.03] text-slate-200"><Download className="size-4" /> Export roster</Button>} />
      <div className="privacy-banner"><LockKeyhole className="size-5" /><div><strong>Privacy boundary active</strong><span>Agents see “redeploy required” or “acclimatisation incomplete”—never the underlying reason.</span></div><Badge variant="outline" className="ml-auto border-emerald-400/20 text-emerald-300">Data minimised</Badge></div>
      <section className="panel data-table-panel">
        <Table>
          <TableHeader><TableRow><TableHead>Crew</TableHead><TableHead>Task</TableHead><TableHead>Zone</TableHead><TableHead>Workers</TableHead><TableHead>Safety context</TableHead></TableRow></TableHeader>
          <TableBody>{demoCrews.map((crew) => <TableRow key={crew.id}><TableCell><div className="table-primary">{crew.name}</div><div className="table-secondary">{crew.id}</div></TableCell><TableCell>{crew.task}</TableCell><TableCell>{crew.zone}</TableCell><TableCell className="font-mono">{crew.workers}</TableCell><TableCell>{crew.vulnerableWorkers > 0 ? <RiskPill risk="Redeploy" /> : !crew.acclimatised ? <RiskPill risk="Acclimatise" /> : <RiskPill risk="Ready" />}</TableCell></TableRow>)}</TableBody>
        </Table>
      </section>
    </>
  );
}

function NotificationsView(props: FeatureViewProps) {
  if (props.flowState !== 'approved') return <EmptyState icon={<Bell />} title="No approved break to send yet" body="Run the record-heat replay and approve the validated plan. Worker notifications will appear here immediately." action={<Button className="replan-button" onClick={() => props.onNavigate('Replay lab')}><Play className="size-4" /> Open replay lab</Button>} />;
  const recipients = [
    ['Arun Kumar', 'Tamil', 'Received', '12s'], ['Nur Aisyah', 'Malay', 'Received', '10s'], ['Li Wei', 'Mandarin', 'Delivered', '8s'], ['Rahim Uddin', 'Bengali', 'Delivered', '8s'], ['Marcus Tan', 'English', 'Received', '6s'],
  ];
  return (
    <>
      <ViewHeading kicker="NOTIFICATIONS · LIVE" title="Approved breaks reached the people who need them." description="Every message carries the approved action, time, location and a clear way to ask for help." action={<Badge className="border border-emerald-400/20 bg-emerald-400/10 px-3 py-1.5 text-emerald-200"><CheckCircle2 className="mr-1 size-4" /> 5 sent</Badge>} />
      <div className="notification-layout">
        <section className="panel notification-feed">
          <div className="panel-heading table-panel-heading"><div><p className="panel-kicker">DELIVERY LEDGER</p><h2>Decision {props.decisionId}</h2></div><Badge variant="outline" className="border-white/10 text-slate-300">In-app + push</Badge></div>
          {recipients.map(([name, lang, status, time]) => <div className="delivery-row" key={name}><div className="delivery-avatar">{name.split(' ').map((part) => part[0]).join('')}</div><div><strong>{name}</strong><span><Languages className="size-3.5" />{lang}</span></div><div className="ml-auto text-right"><RiskPill risk={status} /><small>{time} ago</small></div></div>)}
        </section>
        <WorkerPhone language={props.language} onLanguageChange={props.onLanguageChange} response={props.workerResponse} onResponse={props.onWorkerResponse} />
      </div>
    </>
  );
}

function WorkerPhone({ language, onLanguageChange, response, onResponse }: { language: keyof typeof workerMessages; onLanguageChange: (language: keyof typeof workerMessages) => void; response: FeatureViewProps['workerResponse']; onResponse: FeatureViewProps['onWorkerResponse'] }) {
  return (
    <section className="worker-phone" aria-label="Worker notification preview">
      <div className="phone-status"><span>13:45</span><span>HEATSHIFT WORKER</span><Radio className="size-3.5" /></div>
      <div className="phone-toolbar"><div className="logo-mark"><Waves className="size-4" /></div><Select value={language} onValueChange={(value) => onLanguageChange(value as keyof typeof workerMessages)}><SelectTrigger className="w-[132px] border-white/10 bg-white/[.04] text-slate-200"><Globe2 className="size-4" /><SelectValue /></SelectTrigger><SelectContent>{Object.keys(workerMessages).map((item) => <SelectItem key={item} value={item}>{item}</SelectItem>)}</SelectContent></Select></div>
      <div className="approved-badge"><CheckCircle2 className="size-5" /> BREAK APPROVED</div>
      <h2>Move to a cool rest area now.</h2>
      <p className="worker-message">{workerMessages[language]}</p>
      <div className="rest-ticket"><div><span>START</span><strong>13:45</strong></div><ArrowRight className="size-5" /><div><span>DURATION</span><strong>15 min</strong></div><div className="ticket-place"><MapPin className="size-4" /><span>Cool Bay 03 · 2 min walk</span></div></div>
      <div className="hydration-note"><Droplets className="size-5" /><span>Drink approximately 300 ml of water during this hour.</span></div>
      {response ? <div className={`worker-response response-${response}`}><CheckCircle2 className="size-5" /><div><strong>{response === 'received' ? 'Supervisor can see you received this' : 'Support request sent'}</strong><span>{response === 'received' ? 'Your acknowledgement is recorded.' : 'Stay in shade. Your supervisor has been alerted.'}</span></div></div> : <div className="worker-actions"><Button onClick={() => onResponse('received')} className="w-full bg-emerald-400 text-emerald-950 hover:bg-emerald-300"><Check className="size-4" /> I received this</Button><div><Button variant="outline" onClick={() => onResponse('needs_help')}><MessageCircleWarning className="size-4" /> Need help</Button><Button variant="outline" onClick={() => onResponse('cannot_comply')}><AlertTriangle className="size-4" /> Cannot comply</Button></div></div>}
      <button className="sos-button" type="button"><span>SOS</span> Heat illness emergency</button>
    </section>
  );
}

function DecisionsView({ flowState, decisionId, onOpenDecision, onNavigate }: { flowState: FlowState; decisionId: string; onOpenDecision: () => void; onNavigate: (view: ViewName) => void }) {
  return (
    <>
      <ViewHeading kicker="DECISION CONTROL" title="The agent recommends. A human remains accountable." description="Unsafe, incomplete or unapproved plans are blocked from activation by design." />
      <div className="decision-layout">
        <article className="panel decision-card"><div className="decision-status"><div className={`status-icon ${flowState === 'approved' ? 'success' : 'pending'}`}>{flowState === 'approved' ? <CheckCircle2 /> : <Pause />}</div><div><p className="panel-kicker">{flowState === 'approved' ? 'APPROVED' : 'PENDING HUMAN REVIEW'}</p><h2>{flowState === 'approved' ? decisionId : 'HS-251031-042'}</h2></div></div><p className="mt-5 text-base leading-7 text-slate-300">Four targeted changes create continuous cool-rest windows while preserving the concrete milestone and rest-bay capacity.</p><div className="impact-grid"><Metric label="Exposure reduction" value="38%" detail="projected" /><Metric label="Schedule delay" value="0 min" detail="critical path" /><Metric label="Rules passed" value="12/12" detail="deterministic" /></div><Button onClick={flowState === 'approved' ? () => onNavigate('Evidence') : onOpenDecision} className="replan-button mt-6 w-full">{flowState === 'approved' ? <FileCheck2 className="size-4" /> : <ClipboardCheck className="size-4" />}{flowState === 'approved' ? 'Open evidence certificate' : 'Review decision'}</Button></article>
        <article className="panel boundary-card"><p className="panel-kicker">CONTROL BOUNDARY</p><h2>Four independent protections</h2><Boundary icon={<Bot />} title="Agent" body="May interpret context and propose options." /><Boundary icon={<Workflow />} title="Rules engine" body="Owns thresholds and minimum rest logic." /><Boundary icon={<ShieldCheck />} title="Independent validator" body="Rechecks the complete plan before review." /><Boundary icon={<HardHat />} title="Supervisor" body="Approves, rejects or requests a safer plan." /></article>
      </div>
    </>
  );
}

function Boundary({ icon, title, body }: { icon: ReactNode; title: string; body: string }) {
  return <div className="boundary-row"><div>{icon}</div><span><strong>{title}</strong><small>{body}</small></span></div>;
}

function ReplayView({ onStartReplay, flowState, onNavigate }: { onStartReplay: () => void; flowState: FlowState; onNavigate: (view: ViewName) => void }) {
  return (
    <>
      <ViewHeading kicker="REPLAY LAB · REAL DATA" title="Re-run Singapore’s record-heat day as evidence." description="This scenario uses the preserved NEA WBGT record from 31 October 2025—not hand-typed demo values." action={<Button className="replan-button" onClick={flowState === 'approved' ? () => onNavigate('Evidence') : onStartReplay}>{flowState === 'approved' ? <FileCheck2 className="size-4" /> : <Play className="size-4" />}{flowState === 'approved' ? 'View completed run' : flowState === 'running' ? 'Replay running…' : 'Run record heat event'}</Button>} />
      <div className="replay-layout">
        <section className="panel replay-timeline"><div className="replay-date"><span>31</span><div><strong>October 2025</strong><small>Sentosa Palawan Green · Station S142</small></div><Badge className="ml-auto border border-orange-400/20 bg-orange-400/10 text-orange-200">35.0°C PEAK</Badge></div><div className="timeline-track"><span className="rule-line" /><span className="peak-pin" style={{ left: '59%' }}><i /><strong>12:15</strong><small>35.0°C</small></span>{heatPoints.map((point, index) => <i key={index} className={point >= 33 ? 'hot' : ''} style={{ height: `${28 + (point - 31) * 13}px` }} />)}</div><div className="timeline-labels"><span>10:00</span><span>11:00</span><span>12:00</span><span>13:00</span><span>13:45</span></div><div className="replay-controls"><Button variant="outline" className="border-white/10 bg-white/[.03] text-slate-300"><Pause className="size-4" /> Pause</Button><div className="flex-1"><Progress value={flowState === 'running' ? 64 : flowState === 'approved' || flowState === 'review' ? 100 : 0} className="h-1.5 bg-white/8 [&>div]:bg-cyan-300" /></div><span className="font-mono text-xs text-slate-400">15× speed</span></div></section>
        <aside className="panel provenance-card"><p className="panel-kicker">PROVENANCE</p><h2>Evidence, not theatre</h2><ProvenanceRow label="Publisher" value="National Environment Agency" /><ProvenanceRow label="Platform" value="data.gov.sg" /><ProvenanceRow label="Resolution" value="15 minutes" /><ProvenanceRow label="Coverage" value="96 intervals · 15 stations" /><ProvenanceRow label="Integrity" value="SHA-256 manifest verified" /><a href="https://api-open.data.gov.sg/v2/real-time/api/weather?api=wbgt" target="_blank" rel="noreferrer" className="source-link"><Database className="size-4" /> Open source endpoint <ArrowRight className="ml-auto size-4" /></a></aside>
      </div>
    </>
  );
}

function ProvenanceRow({ label, value }: { label: string; value: string }) { return <div className="provenance-row"><span>{label}</span><strong>{value}</strong></div>; }

function EvidenceView({ flowState, decisionId, certificateHash, plan, onNavigate }: { flowState: FlowState; decisionId: string; certificateHash: string; plan: ReturnType<typeof buildSafePlan>; onNavigate: (view: ViewName) => void }) {
  if (flowState !== 'approved') return <EmptyState icon={<FileCheck2 />} title="Evidence is issued after approval" body="A certificate binds the observation, rules, plan, human decision and notification results into one tamper-evident record." action={<Button className="replan-button" onClick={() => onNavigate('Replay lab')}><Play className="size-4" /> Run evidence replay</Button>} />;
  const download = () => {
    const payload = { schemaVersion: '1.0', decisionId, agentRunId: 'HS-251031-042', observation: { source: 'NEA via data.gov.sg', station: 'S142', observedAt: '2025-10-31T12:15:00+08:00', wbgtC: 35 }, ruleset: 'SG_MOM_OUTDOOR_HEAT_2026_09_04', plan, humanDecision: 'approved', notifications: { sent: 5, languages: Object.keys(workerMessages) }, certificateHash };
    const url = URL.createObjectURL(new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' }));
    const anchor = document.createElement('a'); anchor.href = url; anchor.download = `heatshift-${decisionId}.json`; anchor.click(); URL.revokeObjectURL(url);
  };
  return (
    <>
      <ViewHeading kicker="EVIDENCE" title="A decision judges can inspect—not just trust." description="The certificate records what was sensed, why the plan was safe, who approved it and whether workers received it." action={<Button className="replan-button" onClick={download}><Download className="size-4" /> Download certificate</Button>} />
      <section className="certificate panel">
        <div className="certificate-top"><div className="certificate-seal"><ShieldCheck /></div><div><p className="panel-kicker text-emerald-300">VERIFIED SAFETY DECISION</p><h2>{decisionId}</h2><p>Jurong Innovation District · 31 Oct 2025 · 12:15 SGT</p></div><Badge className="ml-auto border border-emerald-400/20 bg-emerald-400/10 text-emerald-200">CHAIN VALID</Badge></div>
        <div className="evidence-chain"><EvidenceNode icon={<Database />} title="Observation" value="35.0°C · S142" detail="NEA via data.gov.sg" /><ArrowRight /><EvidenceNode icon={<Workflow />} title="Rules" value="12 / 12 passed" detail="MOM 2026 ruleset" /><ArrowRight /><EvidenceNode icon={<HardHat />} title="Human" value="Approved" detail="Safety supervisor" /><ArrowRight /><EvidenceNode icon={<Bell />} title="Delivery" value="5 sent" detail="5 languages" /></div>
        <div className="hash-block"><LockKeyhole className="size-4" /><div><span>Certificate digest</span><code>{certificateHash}</code></div></div>
        <div className="certificate-grid"><div><span>Record observation</span><strong>35.0°C WBGT</strong><small>Sentosa Palawan Green · S142 · 12:15</small></div><div><span>Plan effect</span><strong>38% less exposure</strong><small>0 minutes critical-path delay</small></div><div><span>Worker loop</span><strong>5 notifications</strong><small>3 received · 2 delivered</small></div><div><span>Governance</span><strong>Human approved</strong><small>LLM never activates schedules</small></div></div>
      </section>
    </>
  );
}

function EvidenceNode({ icon, title, value, detail }: { icon: ReactNode; title: string; value: string; detail: string }) { return <div className="evidence-node"><div>{icon}</div><span>{title}</span><strong>{value}</strong><small>{detail}</small></div>; }

function EmptyState({ icon, title, body, action }: { icon: ReactNode; title: string; body: string; action: ReactNode }) {
  return <section className="empty-view panel"><div className="empty-icon">{icon}</div><p className="panel-kicker">WORKFLOW READY</p><h1>{title}</h1><p>{body}</p>{action}</section>;
}

function DecisionReviewDialog({ open, onOpenChange, onApprove, plan, validation }: { open: boolean; onOpenChange: (open: boolean) => void; onApprove: () => void; plan: ReturnType<typeof buildSafePlan>; validation: ReturnType<typeof validatePlan> }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="decision-dialog max-h-[92vh] overflow-y-auto border-white/10 bg-[#0a1726] p-0 sm:max-w-[960px]">
        <DialogHeader className="dialog-head p-6 pb-5"><div className="flex items-start gap-4"><div className="agent-icon"><Bot className="size-5" /></div><div><p className="panel-kicker text-violet-300">SUPERVISOR DECISION</p><DialogTitle className="mt-1 text-xl text-white">Approve four protected work-rest changes?</DialogTitle><DialogDescription className="mt-2 max-w-2xl leading-6 text-slate-400">The agent proposed this plan. Deterministic rules independently validated it. Approval will activate the changes and notify workers.</DialogDescription></div></div></DialogHeader>
        <div className="dialog-metrics"><Metric label="WBGT input" value="35.0°C" detail="NEA station S142" /><Metric label="Exposure reduction" value="38%" detail="projected" /><Metric label="Milestone delay" value="0 min" detail="critical path" /><Metric label="Validation" value={`${validation.checks.filter((check) => check.passed).length}/6`} detail="all mandatory" /></div>
        <div className="px-6 py-5"><Table><TableHeader><TableRow><TableHead>Crew</TableHead><TableHead>Approved action</TableHead><TableHead>Rest</TableHead><TableHead>Location</TableHead><TableHead>Reason</TableHead></TableRow></TableHeader><TableBody>{plan.map((item) => <TableRow key={item.crewId}><TableCell><div className="table-primary">{item.crew}</div><div className="table-secondary">{item.crewId}</div></TableCell><TableCell className="max-w-[230px]">{item.action}</TableCell><TableCell className="font-mono text-emerald-300">{item.restMinutes}m</TableCell><TableCell>{item.restBay}</TableCell><TableCell className="max-w-[190px] text-slate-400">{item.reason}</TableCell></TableRow>)}</TableBody></Table><div className="validation-row">{validation.checks.map((check) => <span key={check.id}><CheckCircle2 className="size-4" />{check.label}</span>)}</div></div>
        <DialogFooter className="m-0 border-white/8 bg-white/[.025] px-6 py-4"><Button variant="outline" onClick={() => onOpenChange(false)} className="border-white/10 bg-transparent text-slate-300">Request revision</Button><Button onClick={onApprove} className="replan-button"><ShieldCheck className="size-4" /> Approve & notify workers</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
