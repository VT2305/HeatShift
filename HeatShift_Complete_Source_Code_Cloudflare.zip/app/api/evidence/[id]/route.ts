import { getChatGPTUser } from '@/app/chatgpt-auth';
import { getD1 } from '@/db/d1';

export async function GET(_request: Request, context: { params: Promise<{ id: string }> }) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: 'authentication_required' }, { status: 401 });
  const { id } = await context.params;
  if (!/^DEC-[A-Z0-9-]{6,32}$/.test(id)) return Response.json({ error: 'invalid_decision_id' }, { status: 400 });
  const db = getD1();
  const decision = await db.prepare('SELECT * FROM decisions WHERE id = ?').bind(id).first();
  if (!decision) return Response.json({ error: 'decision_not_found' }, { status: 404 });
  const [audit, notifications] = await Promise.all([
    db.prepare('SELECT actor_role, action, event_hash, previous_hash, created_at FROM audit_events WHERE decision_id = ? ORDER BY created_at ASC').bind(id).all(),
    db.prepare('SELECT recipient_id, language, channel, status, sent_at, acknowledged_at FROM notifications WHERE decision_id = ? ORDER BY sent_at ASC').bind(id).all(),
  ]);
  return Response.json({ schemaVersion: '1.0', generatedAt: new Date().toISOString(), decision, audit: audit.results, notifications: notifications.results }, {
    headers: { 'Cache-Control': 'no-store', 'Content-Disposition': `attachment; filename="heatshift-${id}.json"`, 'X-Content-Type-Options': 'nosniff' },
  });
}
