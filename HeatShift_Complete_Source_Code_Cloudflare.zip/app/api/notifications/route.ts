import { getChatGPTUser } from '@/app/chatgpt-auth';
import { getD1 } from '@/db/d1';

export async function GET(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: 'authentication_required' }, { status: 401 });
  const decisionId = new URL(request.url).searchParams.get('decisionId');
  if (!decisionId || !/^DEC-[A-Z0-9-]{6,32}$/.test(decisionId)) return Response.json({ error: 'invalid_decision_id' }, { status: 400 });
  const result = await getD1().prepare(`
    SELECT n.id, n.recipient_id, n.recipient_name, n.language, n.title, n.body,
           n.channel, n.status, n.sent_at, n.acknowledged_at
    FROM notifications n
    JOIN decisions d ON d.id = n.decision_id
    WHERE n.decision_id = ? AND (d.approved_by = ? OR n.recipient_id = ?)
    ORDER BY n.sent_at ASC
  `).bind(decisionId, user.userId, user.userId).all();
  return Response.json({ notifications: result.results }, { headers: { 'Cache-Control': 'no-store' } });
}

export async function PATCH(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: 'authentication_required' }, { status: 401 });
  type NotificationUpdate = { id?: unknown; response?: unknown };
  let body: NotificationUpdate | null = null;
  try { body = await request.json() as NotificationUpdate; } catch { /* handled below */ }
  const id = typeof body?.id === 'string' ? body.id : '';
  const response = ['received', 'needs_help', 'cannot_comply'].includes(String(body?.response)) ? String(body?.response) : '';
  if (!/^NTF-[0-9a-f-]{20,50}$/i.test(id) || !response) return Response.json({ error: 'invalid_request' }, { status: 400 });
  const acknowledgedAt = new Date().toISOString();
  const result = await getD1().prepare('UPDATE notifications SET status = ?, acknowledged_at = ? WHERE id = ? AND recipient_id = ? AND status = ?').bind(response, acknowledgedAt, id, user.userId, 'sent').run();
  if (!result.meta.changes) return Response.json({ error: 'notification_not_actionable' }, { status: 409 });
  return Response.json({ id, status: response, acknowledgedAt }, { headers: { 'Cache-Control': 'no-store' } });
}
