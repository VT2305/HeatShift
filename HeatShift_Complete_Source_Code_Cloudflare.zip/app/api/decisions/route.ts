import { getChatGPTUser } from '@/app/chatgpt-auth';
import { getD1, sha256Hex } from '@/db/d1';
import { RULESET_ID, type PlanChange, validatePlan } from '@/lib/safety-engine';

type DecisionRequest = { agentRunId?: unknown; action?: unknown; rationale?: unknown };
type StoredRun = {
  id: string;
  site_id: string;
  wbgt_tenths: number;
  status: string;
  plan_json: string;
  guardrails_json: string;
};

const workers = [
  ['WK-1008', 'Arun Kumar', 'Tamil', 'உங்கள் 15 நிமிட குளிர் ஓய்வு 13:45க்கு Cool Bay 03-ல் அங்கீகரிக்கப்பட்டது.'],
  ['WK-1017', 'Nur Aisyah', 'Malay', 'Rehat sejuk 15 minit anda diluluskan pada 13:50 di Cool Bay 07.'],
  ['WK-1034', 'Li Wei', 'Mandarin', '您的15分钟降温休息已获批准，13:55前往 North Welfare Hub。'],
  ['WK-1062', 'Rahim Uddin', 'Bengali', 'আপনার ১৫ মিনিটের শীতল বিরতি অনুমোদিত হয়েছে। ১৪:০০-এ West Rest Pod-এ যান।'],
  ['WK-1091', 'Marcus Tan', 'English', 'Your 15-minute cool rest is approved. Report to Cool Bay 03 at 13:45.'],
] as const;

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: 'authentication_required' }, { status: 401 });
  const idempotencyKey = request.headers.get('Idempotency-Key');
  if (!idempotencyKey || idempotencyKey.length < 8 || idempotencyKey.length > 100) {
    return Response.json({ error: 'idempotency_key_required' }, { status: 400 });
  }

  let body: DecisionRequest | null = null;
  try { body = await request.json() as DecisionRequest; } catch { /* handled below */ }
  const agentRunId = typeof body?.agentRunId === 'string' ? body.agentRunId : '';
  const action = body?.action === 'approved' || body?.action === 'rejected' ? body.action : null;
  const rationale = typeof body?.rationale === 'string' ? body.rationale.trim() : '';
  if (!/^HS-[A-Z0-9-]{8,40}$/.test(agentRunId) || !action || rationale.length < 8 || rationale.length > 600) {
    return Response.json({ error: 'invalid_request' }, { status: 400 });
  }

  const db = getD1();
  const existing = await db.prepare('SELECT id, status, certificate_hash FROM decisions WHERE agent_run_id = ?').bind(agentRunId).first();
  if (existing) return Response.json({ decision: existing, replayed: true }, { headers: secureHeaders() });

  const run = await db.prepare('SELECT id, site_id, wbgt_tenths, status, plan_json, guardrails_json FROM agent_runs WHERE id = ?').bind(agentRunId).first<StoredRun>();
  if (!run) return Response.json({ error: 'agent_run_not_found' }, { status: 404 });
  if (run.status !== 'awaiting_approval') return Response.json({ error: 'agent_run_not_actionable' }, { status: 409 });

  const plan = JSON.parse(run.plan_json) as PlanChange[];
  const validation = validatePlan(run.wbgt_tenths / 10, plan);
  if (!validation.valid) return Response.json({ error: 'guardrail_validation_failed', validation }, { status: 422 });

  const approvedAt = new Date().toISOString();
  const decisionId = `DEC-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const certificatePayload = JSON.stringify({
    decisionId,
    agentRunId,
    siteId: run.site_id,
    action,
    approvedAt,
    approvedBy: user.userId,
    rulesetId: RULESET_ID,
    plan,
    validation,
  });
  const certificateHash = await sha256Hex(certificatePayload);
  const auditHash = await sha256Hex(`${idempotencyKey}:${certificateHash}`);

  const statements = [
    db.prepare(`INSERT INTO decisions (id, agent_run_id, site_id, status, rationale, ruleset_id, approved_by, approved_at, plan_json, certificate_hash) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(decisionId, agentRunId, run.site_id, action, rationale, RULESET_ID, user.userId, approvedAt, run.plan_json, certificateHash),
    db.prepare('UPDATE agent_runs SET status = ? WHERE id = ? AND status = ?').bind(action, agentRunId, 'awaiting_approval'),
    db.prepare(`INSERT INTO audit_events (id, decision_id, actor_id, actor_role, action, payload_json, previous_hash, event_hash, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .bind(`AUD-${crypto.randomUUID()}`, decisionId, user.userId, 'safety_supervisor', `plan_${action}`, certificatePayload, null, auditHash, approvedAt),
  ];

  if (action === 'approved') {
    for (const [recipientId, recipientName, language, message] of workers) {
      statements.push(db.prepare(`INSERT INTO notifications (id, decision_id, recipient_id, recipient_name, language, title, body, channel, status, sent_at, acknowledged_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
        .bind(`NTF-${crypto.randomUUID()}`, decisionId, recipientId, recipientName, language, 'Break approved · HeatShift', message, 'in_app', 'sent', approvedAt, null));
    }
  }
  await db.batch(statements);

  return Response.json({
    decision: { id: decisionId, agentRunId, status: action, approvedAt, approvedBy: user.displayName, certificateHash },
    notificationsSent: action === 'approved' ? workers.length : 0,
    validation,
  }, { status: 201, headers: secureHeaders() });
}

function secureHeaders() {
  return { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
}
