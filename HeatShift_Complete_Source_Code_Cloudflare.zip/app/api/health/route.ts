export async function GET() {
  return Response.json({
    service: 'heatshift-control-plane',
    status: 'ok',
    ruleset: 'SG_MOM_OUTDOOR_HEAT_2026_09_04',
    guardrails: 'deterministic',
    humanApprovalRequired: true,
  }, {
    headers: {
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    },
  });
}
