import { getChatGPTUser } from '@/app/chatgpt-auth';
import { getD1 } from '@/db/d1';
import { buildSafePlan, demoCrews, RULESET_ID, validatePlan } from '@/lib/safety-engine';

type RunRequest = {
  siteId?: unknown;
  wbgt?: unknown;
  observationTime?: unknown;
};

export async function POST(request: Request) {
  const user = await getChatGPTUser();
  if (!user) return Response.json({ error: 'authentication_required' }, { status: 401 });

  const body = await safeJson<RunRequest>(request);
  const siteId = typeof body?.siteId === 'string' ? body.siteId : '';
  const wbgt = typeof body?.wbgt === 'number' ? body.wbgt : Number.NaN;
  const observationTime = typeof body?.observationTime === 'string' ? body.observationTime : '';
  if (!/^SITE-[A-Z0-9-]{2,32}$/.test(siteId) || !Number.isFinite(wbgt) || wbgt < 20 || wbgt > 50 || !isIsoDate(observationTime)) {
    return Response.json({ error: 'invalid_request' }, { status: 400 });
  }

  const plan = buildSafePlan(wbgt, demoCrews);
  const validation = validatePlan(wbgt, plan);
  if (!validation.valid) return Response.json({ error: 'no_safe_plan', validation }, { status: 422 });

  const run = {
    id: `HS-${observationTime.slice(2, 10).replaceAll('-', '')}-${crypto.randomUUID().slice(0, 6).toUpperCase()}`,
    siteId,
    observationTime,
    wbgt,
    status: 'awaiting_approval' as const,
    plan,
    validation,
    rulesetId: RULESET_ID,
    createdAt: new Date().toISOString(),
  };

  const db = getD1();
  await db.prepare(`
    INSERT INTO agent_runs (
      id, site_id, observation_time, wbgt_tenths, status,
      plan_json, guardrails_json, created_by, created_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    run.id,
    run.siteId,
    run.observationTime,
    Math.round(run.wbgt * 10),
    run.status,
    JSON.stringify(run.plan),
    JSON.stringify(run.validation),
    user.userId,
    run.createdAt,
  ).run();

  return Response.json(run, { status: 201, headers: secureNoStoreHeaders() });
}

async function safeJson<T>(request: Request): Promise<T | null> {
  try { return await request.json() as T; } catch { return null; }
}

function isIsoDate(value: string) {
  return value.length <= 40 && Number.isFinite(Date.parse(value));
}

function secureNoStoreHeaders() {
  return { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
}
