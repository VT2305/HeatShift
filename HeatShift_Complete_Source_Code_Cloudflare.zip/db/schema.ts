import { index, integer, sqliteTable, text, uniqueIndex } from 'drizzle-orm/sqlite-core';

export const agentRuns = sqliteTable('agent_runs', {
  id: text('id').primaryKey(),
  siteId: text('site_id').notNull(),
  observationTime: text('observation_time').notNull(),
  wbgtTenths: integer('wbgt_tenths').notNull(),
  status: text('status', { enum: ['planning', 'awaiting_approval', 'approved', 'rejected'] }).notNull(),
  planJson: text('plan_json').notNull(),
  guardrailsJson: text('guardrails_json').notNull(),
  createdBy: text('created_by').notNull(),
  createdAt: text('created_at').notNull(),
}, (table) => [
  index('idx_agent_runs_site_created').on(table.siteId, table.createdAt),
  index('idx_agent_runs_status').on(table.status),
]);

export const decisions = sqliteTable('decisions', {
  id: text('id').primaryKey(),
  agentRunId: text('agent_run_id').notNull(),
  siteId: text('site_id').notNull(),
  status: text('status', { enum: ['approved', 'rejected'] }).notNull(),
  rationale: text('rationale').notNull(),
  rulesetId: text('ruleset_id').notNull(),
  approvedBy: text('approved_by').notNull(),
  approvedAt: text('approved_at').notNull(),
  planJson: text('plan_json').notNull(),
  certificateHash: text('certificate_hash').notNull(),
}, (table) => [
  uniqueIndex('idx_decisions_agent_run').on(table.agentRunId),
  index('idx_decisions_site_approved').on(table.siteId, table.approvedAt),
]);

export const notifications = sqliteTable('notifications', {
  id: text('id').primaryKey(),
  decisionId: text('decision_id').notNull(),
  recipientId: text('recipient_id').notNull(),
  recipientName: text('recipient_name').notNull(),
  language: text('language').notNull(),
  title: text('title').notNull(),
  body: text('body').notNull(),
  channel: text('channel').notNull().default('in_app'),
  status: text('status', { enum: ['sent', 'received', 'needs_help', 'cannot_comply'] }).notNull(),
  sentAt: text('sent_at').notNull(),
  acknowledgedAt: text('acknowledged_at'),
}, (table) => [
  index('idx_notifications_recipient_status').on(table.recipientId, table.status),
  index('idx_notifications_decision').on(table.decisionId),
]);

export const auditEvents = sqliteTable('audit_events', {
  id: text('id').primaryKey(),
  decisionId: text('decision_id').notNull(),
  actorId: text('actor_id').notNull(),
  actorRole: text('actor_role').notNull(),
  action: text('action').notNull(),
  payloadJson: text('payload_json').notNull(),
  previousHash: text('previous_hash'),
  eventHash: text('event_hash').notNull(),
  createdAt: text('created_at').notNull(),
}, (table) => [
  index('idx_audit_events_decision_created').on(table.decisionId, table.createdAt),
  uniqueIndex('idx_audit_events_hash').on(table.eventHash),
]);
