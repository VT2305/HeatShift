CREATE TABLE `agent_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`site_id` text NOT NULL,
	`observation_time` text NOT NULL,
	`wbgt_tenths` integer NOT NULL,
	`status` text NOT NULL,
	`plan_json` text NOT NULL,
	`guardrails_json` text NOT NULL,
	`created_by` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_agent_runs_site_created` ON `agent_runs` (`site_id`,`created_at`);--> statement-breakpoint
CREATE INDEX `idx_agent_runs_status` ON `agent_runs` (`status`);--> statement-breakpoint
CREATE TABLE `audit_events` (
	`id` text PRIMARY KEY NOT NULL,
	`decision_id` text NOT NULL,
	`actor_id` text NOT NULL,
	`actor_role` text NOT NULL,
	`action` text NOT NULL,
	`payload_json` text NOT NULL,
	`previous_hash` text,
	`event_hash` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_audit_events_decision_created` ON `audit_events` (`decision_id`,`created_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_audit_events_hash` ON `audit_events` (`event_hash`);--> statement-breakpoint
CREATE TABLE `decisions` (
	`id` text PRIMARY KEY NOT NULL,
	`agent_run_id` text NOT NULL,
	`site_id` text NOT NULL,
	`status` text NOT NULL,
	`rationale` text NOT NULL,
	`ruleset_id` text NOT NULL,
	`approved_by` text NOT NULL,
	`approved_at` text NOT NULL,
	`plan_json` text NOT NULL,
	`certificate_hash` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_decisions_agent_run` ON `decisions` (`agent_run_id`);--> statement-breakpoint
CREATE INDEX `idx_decisions_site_approved` ON `decisions` (`site_id`,`approved_at`);--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` text PRIMARY KEY NOT NULL,
	`decision_id` text NOT NULL,
	`recipient_id` text NOT NULL,
	`recipient_name` text NOT NULL,
	`language` text NOT NULL,
	`title` text NOT NULL,
	`body` text NOT NULL,
	`channel` text DEFAULT 'in_app' NOT NULL,
	`status` text NOT NULL,
	`sent_at` text NOT NULL,
	`acknowledged_at` text
);
--> statement-breakpoint
CREATE INDEX `idx_notifications_recipient_status` ON `notifications` (`recipient_id`,`status`);--> statement-breakpoint
CREATE INDEX `idx_notifications_decision` ON `notifications` (`decision_id`);
--> statement-breakpoint
PRAGMA optimize;
