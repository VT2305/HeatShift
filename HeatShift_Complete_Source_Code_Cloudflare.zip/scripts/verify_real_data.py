"""Verify the preserved HeatShift source pack before a demo or deployment."""

from __future__ import annotations

import csv
import hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "data" / "real-world"
MANIFEST = ROOT / "sha256_manifest.csv"


def main() -> None:
    failures: list[str] = []
    checked = 0
    with MANIFEST.open(newline="", encoding="utf-8-sig") as handle:
        for row in csv.DictReader(handle):
            path = ROOT / row["relative_path"]
            if not path.is_file():
                failures.append(f"missing: {row['relative_path']}")
                continue
            payload = path.read_bytes()
            digest = hashlib.sha256(payload).hexdigest()
            if len(payload) != int(row["bytes"]):
                failures.append(f"size mismatch: {row['relative_path']}")
            if digest != row["sha256"]:
                failures.append(f"hash mismatch: {row['relative_path']}")
            checked += 1
    if failures:
        raise SystemExit("Real-data verification failed:\n- " + "\n- ".join(failures))
    print(f"Verified {checked} source files against {MANIFEST.name}.")


if __name__ == "__main__":
    main()
