param(
  [switch]$EnableBedrock
)

$ErrorActionPreference = 'Stop'
$expectedRegion = 'us-east-1'
$repoRoot = Split-Path -Parent $PSScriptRoot
$templatePath = Join-Path $repoRoot 'infra\aws\template.yaml'

if (-not (Get-Command aws -ErrorAction SilentlyContinue)) {
  throw 'AWS CLI is required. Install it before leasing the Innovation Sandbox account.'
}
if (-not (Get-Command sam -ErrorAction SilentlyContinue)) {
  throw 'AWS SAM CLI is required to build and deploy the sandbox stack.'
}

$identity = aws sts get-caller-identity --output json | ConvertFrom-Json
if (-not $identity.Account) {
  throw 'No active AWS Sandbox identity. Lease the account, then configure its temporary credentials locally.'
}

$region = aws configure get region
if ($region -ne $expectedRegion) {
  throw "HeatShift sandbox deployment is pinned to $expectedRegion. Current region: $region"
}

$bedrockValue = if ($EnableBedrock) { 'true' } else { 'false' }
sam validate --template-file $templatePath --lint
sam build --template-file $templatePath
sam deploy --parameter-overrides "Environment=sandbox BedrockEnabled=$bedrockValue"
