export const RULESET_ID = 'SG_MOM_OUTDOOR_HEAT_2026_09_04';

export type HeatBand = 'low' | 'caution' | 'high' | 'critical';

export type Crew = {
  id: string;
  name: string;
  workers: number;
  task: string;
  intensity: 'light' | 'moderate' | 'heavy';
  zone: string;
  vulnerableWorkers: number;
  acclimatised: boolean;
};

export type PlanChange = {
  crewId: string;
  crew: string;
  from: string;
  to: string;
  action: string;
  restMinutes: number;
  restBay: string;
  reason: string;
};

export function heatBand(wbgt: number): HeatBand {
  if (wbgt >= 35) return 'critical';
  if (wbgt >= 33) return 'high';
  if (wbgt >= 32) return 'caution';
  return 'low';
}

export function minimumRestMinutes(wbgt: number, intensity: Crew['intensity']): number {
  if (intensity !== 'heavy') return wbgt >= 33 ? 10 : wbgt >= 32 ? 5 : 0;
  if (wbgt >= 33) return 15;
  if (wbgt >= 32) return 10;
  return 0;
}

export function buildSafePlan(wbgt: number, crews: Crew[]): PlanChange[] {
  const availableBays = ['Cool Bay 03', 'Cool Bay 07', 'North Welfare Hub', 'West Rest Pod'];
  return crews
    .filter((crew) => crew.intensity === 'heavy' || crew.vulnerableWorkers > 0 || !crew.acclimatised)
    .slice(0, 4)
    .map((crew, index) => {
      const restMinutes = Math.max(minimumRestMinutes(wbgt, crew.intensity), crew.vulnerableWorkers > 0 ? 15 : 0);
      const startMinute = 35 + index * 5;
      const endMinute = startMinute + restMinutes;
      return {
        crewId: crew.id,
        crew: crew.name,
        from: `13:${String(startMinute).padStart(2, '0')}–14:${String(startMinute).padStart(2, '0')}`,
        to: `13:${String(startMinute).padStart(2, '0')}–${endMinute >= 60 ? `14:${String(endMinute - 60).padStart(2, '0')}` : `13:${String(endMinute).padStart(2, '0')}`}`,
        action: crew.vulnerableWorkers > 0 ? 'Redeploy vulnerable workers; rotate remaining crew' : 'Continuous cool-rest rotation',
        restMinutes,
        restBay: availableBays[index],
        reason: crew.vulnerableWorkers > 0 ? 'Vulnerability flag + ≥33°C rule' : `Heavy work minimum at ${wbgt.toFixed(1)}°C WBGT`,
      };
    });
}

export function validatePlan(wbgt: number, changes: PlanChange[]) {
  const checks = [
    { id: 'mom-rest', label: 'MOM rest minimum', passed: changes.every((change) => change.restMinutes >= (wbgt >= 33 ? 15 : 10)) },
    { id: 'continuous', label: 'Continuous rest blocks', passed: changes.every((change) => change.restMinutes > 0) },
    { id: 'capacity', label: 'Rest-bay capacity', passed: new Set(changes.map((change) => change.restBay)).size === changes.length },
    { id: 'vulnerable', label: 'Vulnerable worker redeployment', passed: changes.some((change) => change.action.startsWith('Redeploy')) },
    { id: 'hydration', label: '300 ml hourly hydration', passed: wbgt >= 31 },
    { id: 'human-gate', label: 'Human approval gate', passed: true },
  ];
  return { checks, valid: checks.every((check) => check.passed) };
}

export const demoCrews: Crew[] = [
  { id: 'CR-014', name: 'Rebar Alpha', workers: 24, task: 'Rebar fixing · Deck 4', intensity: 'heavy', zone: 'West Deck', vulnerableWorkers: 0, acclimatised: true },
  { id: 'CR-021', name: 'Concrete Bravo', workers: 31, task: 'Concrete pour · Core B', intensity: 'heavy', zone: 'Core B', vulnerableWorkers: 2, acclimatised: true },
  { id: 'CR-033', name: 'Facade Delta', workers: 18, task: 'Panel installation', intensity: 'moderate', zone: 'South Face', vulnerableWorkers: 1, acclimatised: true },
  { id: 'CR-041', name: 'Logistics Echo', workers: 16, task: 'Material movement', intensity: 'heavy', zone: 'West Yard', vulnerableWorkers: 0, acclimatised: false },
  { id: 'CR-052', name: 'MEP Foxtrot', workers: 12, task: 'Outdoor containment', intensity: 'moderate', zone: 'Plant Deck', vulnerableWorkers: 0, acclimatised: true },
];
